package com.teaachmeskills.autosalon.entity;

import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import java.util.List;

/**
 * Created by TMS on 17.05.2018.
 */
@XmlRootElement
public class Autos {
    private List<Auto> autos;

    public Autos(List<Auto> autos) {
        this.autos = autos;
    }

    public Autos() {
    }

    @XmlElement(name = "auto")
    public List<Auto> getAutos() {
        return autos;
    }

    public void setAutos(List<Auto> autos) {
        this.autos = autos;
    }
}
