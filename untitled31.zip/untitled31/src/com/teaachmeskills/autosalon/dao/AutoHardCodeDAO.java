package com.teaachmeskills.autosalon.dao;

import com.teaachmeskills.autosalon.entity.Auto;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by TMS on 24.04.2018.
 */
public class AutoHardCodeDAO implements AutoDAO {
    private List<Auto> autos = new ArrayList<>();

    public AutoHardCodeDAO() {
        autos.add(new Auto("Audi", 250, 27500));
        autos.add(new Auto("BMW", 280, 34750));
    }

    @Override
    public List<Auto> getAutos() {
        return autos;
    }

    @Override
    public List<Auto> getAutos(String marka) {
        List<Auto> result = new ArrayList<>();
        for (Auto auto : autos){
            if(auto.getMarka().equalsIgnoreCase(marka)){
                result.add(auto);
            }
        }
        return result;
    }

    @Override
    public void addAuto(Auto auto) {
        autos.add(auto);
    }

    @Override
    public void update(Auto auto) {
//        for (int i = 0; i < autos.length; i++){
//            if(autos[i].getMarka().equalsIgnoreCase(auto.getMarka())){
//                autos[i].setPrice(auto.getPrice());
//                autos[i].setSpeed(auto.getSpeed());
//            }
//        }
    }
}
