package com.teaachmeskills.autosalon.dao;

import com.teaachmeskills.autosalon.entity.Auto;

import java.util.List;

/**
 * Created by TMS on 24.04.2018.
 */
public interface AutoDAO {
    List<Auto> getAutos();
    List<Auto> getAutos(String marka);
    void addAuto(Auto auto);
    void update(Auto auto);
}
