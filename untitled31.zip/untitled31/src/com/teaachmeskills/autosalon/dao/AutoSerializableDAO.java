package com.teaachmeskills.autosalon.dao;

import com.teaachmeskills.autosalon.entity.Auto;
import com.teaachmeskills.autosalon.entity.AutoSortByPrice;
import com.teaachmeskills.autosalon.entity.AutoSoryByMarka;

import java.io.*;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

/**
 * Created by TMS on 15.05.2018.
 */
public class AutoSerializableDAO implements AutoDAO {
    private static final String PATH = "autos_serializable";
    @Override
    public List<Auto> getAutos() {
        try(ObjectInputStream inputStream = new ObjectInputStream(new FileInputStream(PATH))){
            List<Auto> autos = (List<Auto>) inputStream.readObject();
//            Collections.sort(autos);
//            Collections.sort(autos, new AutoSoryByMarka());
//            Collections.sort(autos, (o1, o2) -> o2.getMarka().compareTo(o1.getMarka()));
            return autos;
        }catch (Exception e){
            return new ArrayList<>();
        }
    }

    @Override
    public List<Auto> getAutos(String marka) {
        List<Auto> autos = new ArrayList<>();
        for(Auto auto : getAutos()){
            if(auto.getMarka().equalsIgnoreCase(marka)){
                autos.add(auto);
            }
        }
        return autos;
    }

    @Override
    public void addAuto(Auto auto) {
        List<Auto> autos = getAutos();
        autos.add(auto);
        try(ObjectOutputStream outputStream = new ObjectOutputStream(new FileOutputStream(PATH))){
            outputStream.writeObject(autos);
        } catch (Exception e) {
            System.out.println("Ошибка при записи");
        }
    }

    @Override
    public void update(Auto auto) {

    }


}
