package com.teaachmeskills.autosalon.dao;

import com.teaachmeskills.autosalon.entity.Auto;
import com.teaachmeskills.autosalon.entity.Autos;

import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBException;
import javax.xml.bind.Marshaller;
import javax.xml.bind.Unmarshaller;
import java.io.File;
import java.util.ArrayList;
import java.util.List;

/**
 * Created by TMS on 17.05.2018.
 */
public class AutoXmlDAO implements AutoDAO {
    private static final File FILE = new File("autos.xml");
    @Override
    public List<Auto> getAutos(){
        try {
            JAXBContext context = JAXBContext.newInstance(Autos.class);
            Unmarshaller unmarshaller = context.createUnmarshaller();
            Autos autos = (Autos) unmarshaller.unmarshal(FILE);
            return autos.getAutos();
        } catch (Exception e) {
            return new ArrayList<>();
        }

    }

    @Override
    public List<Auto> getAutos(String marka) {
        return null;
    }

    @Override
    public void addAuto(Auto auto) {
        List<Auto> autoList = getAutos();
        autoList.add(auto);
        Autos autos = new Autos(autoList);
        try {
            JAXBContext context = JAXBContext.newInstance(Autos.class);
            Marshaller marshaller = context.createMarshaller();
            marshaller.setProperty(Marshaller.JAXB_FORMATTED_OUTPUT, true);
            marshaller.marshal(autos, FILE);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    @Override
    public void update(Auto auto) {

    }
}
