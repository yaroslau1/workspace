package com.teaachmeskills.autosalon.dao;

import com.teaachmeskills.autosalon.entity.Auto;

import java.io.*;
import java.util.ArrayList;
import java.util.List;

/**
 * Created by TMS on 10.05.2018.
 */
public class AutoFileDAO implements AutoDAO {
    private static final String PATH = "autos.txt";

    @Override
    public List<Auto> getAutos() {
        try(BufferedReader reader = new BufferedReader(new InputStreamReader(new FileInputStream(PATH)))){
            List<Auto> autos = new ArrayList<>();
            String line = null;
            while ( (line = reader.readLine()) != null ){
                String autoArr[] = line.split("_");
                Auto auto = new Auto();
                auto.setMarka(autoArr[0]);
                auto.setSpeed(Integer.parseInt(autoArr[1]));
                auto.setPrice(Integer.parseInt(autoArr[2]));
                autos.add(auto);
            }
            return autos;
        }catch (IOException e){
            System.out.println("Ошибка при чтении файла");
            return new ArrayList<>();
        }
    }

    @Override
    public List<Auto> getAutos(String marka) {
        try(BufferedReader reader = new BufferedReader(new InputStreamReader(new FileInputStream(PATH)))){
            List<Auto> autos = new ArrayList<>();
            String line = null;
            while ( (line = reader.readLine()) != null ){
                String autoArr[] = line.split("_");
                if(autoArr[0].equalsIgnoreCase(marka)){
                    Auto auto = new Auto();
                    auto.setMarka(autoArr[0]);
                    auto.setSpeed(Integer.parseInt(autoArr[1]));
                    auto.setPrice(Integer.parseInt(autoArr[2]));
                    autos.add(auto);
                }
            }
            return autos;
        }catch (IOException e){
            System.out.println("Ошибка при чтении файла");
            return new ArrayList<>();
        }
    }

    @Override
    public void addAuto(Auto auto) {
        try{
            File file = new File(PATH);
            if(!file.exists()){
                file.createNewFile();
            }
            FileWriter writer = new FileWriter(file, true);
            writer.write(auto.toFileString()+"\n");
            writer.close();
        }catch (IOException e){
            System.out.println("Ошибка при записи");
        }
    }

    @Override
    public void update(Auto auto) {

    }
}
