package com.teaachmeskills.autosalon;

import com.teaachmeskills.autosalon.app.Application;
import com.teaachmeskills.autosalon.entity.Auto;

import java.io.*;

/**
 * Created by TMS on 24.04.2018.
 */
public class Main {
    public static void main(String[] args) {
        Application application = new Application();
        application.start();
    }
}
