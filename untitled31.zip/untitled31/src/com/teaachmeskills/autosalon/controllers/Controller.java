package com.teaachmeskills.autosalon.controllers;

import com.teaachmeskills.autosalon.dao.*;
import com.teaachmeskills.autosalon.entity.Auto;

import java.util.List;

/**
 * Created by TMS on 24.04.2018.
 */
public class Controller {
    private AutoDAO dao = new AutoXmlDAO();

    public List<Auto> getAutos(){
        return dao.getAutos();
    }

    public List<Auto> getAutos(String marka){
        return dao.getAutos(marka);
    }

    public void addAuto(Auto auto){
        if(auto.getSpeed() >= 200){
            auto.setPrice(auto.getPrice() + 1000);
        }
        dao.addAuto(auto);

    }

    public void update(Auto auto) {
        dao.update(auto);
    }
}
